# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(swift_arc src/swift_arc.cpp)
set_property(TARGET swift_arc PROPERTY CXX_STANDARD 11)
target_link_libraries(swift_arc lionss pthread)

add_executable(ocsp-staple src/ocsp-staple.cpp)
set_property(TARGET ocsp-staple PROPERTY CXX_STANDARD 11)
target_link_libraries(ocsp-staple lionss pthread)

add_executable(redis_slotmove src/redis_slotmove.cpp)
set_property(TARGET redis_slotmove PROPERTY CXX_STANDARD 11)
target_link_libraries(redis_slotmove lionss pthread)

add_executable(tiering-osr src/tiering-osr.cpp)
set_property(TARGET tiering-osr PROPERTY CXX_STANDARD 11)
target_link_libraries(tiering-osr lionss pthread)

add_executable(ResnetProbe src/ResnetProbe.cpp)
set_property(TARGET ResnetProbe PROPERTY CXX_STANDARD 11)
target_link_libraries(ResnetProbe lionss pthread)

add_executable(groundTrack src/groundTrack.cpp)
set_property(TARGET groundTrack PROPERTY CXX_STANDARD 11)
target_link_libraries(groundTrack lionss pthread)

add_executable(amber-wave src/amber-wave.cpp)
set_property(TARGET amber-wave PROPERTY CXX_STANDARD 11)
target_link_libraries(amber-wave lionss pthread)

add_executable(stm32h7_blink src/stm32h7_blink.cpp)
set_property(TARGET stm32h7_blink PROPERTY CXX_STANDARD 11)
target_link_libraries(stm32h7_blink lionss pthread)

add_executable(hollowpine src/hollowpine.cpp)
set_property(TARGET hollowpine PROPERTY CXX_STANDARD 11)
target_link_libraries(hollowpine lionss pthread)

add_executable(Halcyon src/Halcyon.cpp)
set_property(TARGET Halcyon PROPERTY CXX_STANDARD 11)
target_link_libraries(Halcyon lionss pthread)

add_executable(Kestrel src/Kestrel.cpp)
set_property(TARGET Kestrel PROPERTY CXX_STANDARD 11)
target_link_libraries(Kestrel lionss pthread)

add_executable(ambisonicb src/ambisonicb.cpp)
set_property(TARGET ambisonicb PROPERTY CXX_STANDARD 11)
target_link_libraries(ambisonicb lionss pthread)

add_executable(sgd-nesterov src/sgd-nesterov.cpp)
set_property(TARGET sgd-nesterov PROPERTY CXX_STANDARD 11)
target_link_libraries(sgd-nesterov lionss pthread)

add_executable(SolverIpopt src/SolverIpopt.cpp)
set_property(TARGET SolverIpopt PROPERTY CXX_STANDARD 11)
target_link_libraries(SolverIpopt lionss pthread)

add_executable(curve_ladder src/curve_ladder.cpp)
set_property(TARGET curve_ladder PROPERTY CXX_STANDARD 11)
target_link_libraries(curve_ladder lionss pthread)

add_executable(avr_watchdog src/avr_watchdog.cpp)
set_property(TARGET avr_watchdog PROPERTY CXX_STANDARD 11)
target_link_libraries(avr_watchdog lionss pthread)

add_executable(spirvopt src/spirvopt.cpp)
set_property(TARGET spirvopt PROPERTY CXX_STANDARD 11)
target_link_libraries(spirvopt lionss pthread)

add_executable(inline-cache src/inline-cache.cpp)
set_property(TARGET inline-cache PROPERTY CXX_STANDARD 11)
target_link_libraries(inline-cache lionss pthread)

add_executable(Larkspur src/Larkspur.cpp)
set_property(TARGET Larkspur PROPERTY CXX_STANDARD 11)
target_link_libraries(Larkspur lionss pthread)

add_executable(raid-resync src/raid-resync.cpp)
set_property(TARGET raid-resync PROPERTY CXX_STANDARD 11)
target_link_libraries(raid-resync lionss pthread)

add_executable(PbrSpecular src/PbrSpecular.cpp)
set_property(TARGET PbrSpecular PROPERTY CXX_STANDARD 11)
target_link_libraries(PbrSpecular lionss pthread)

add_executable(nftables-nat src/nftables-nat.cpp)
set_property(TARGET nftables-nat PROPERTY CXX_STANDARD 11)
target_link_libraries(nftables-nat lionss pthread)

add_executable(sam_sort src/sam_sort.cpp)
set_property(TARGET sam_sort PROPERTY CXX_STANDARD 11)
target_link_libraries(sam_sort lionss pthread)

add_executable(ratelimit src/ratelimit.cpp)
set_property(TARGET ratelimit PROPERTY CXX_STANDARD 11)
target_link_libraries(ratelimit lionss pthread)

add_executable(ssao_kernel src/ssao_kernel.cpp)
set_property(TARGET ssao_kernel PROPERTY CXX_STANDARD 11)
target_link_libraries(ssao_kernel lionss pthread)

add_executable(ZigbeeBind src/ZigbeeBind.cpp)
set_property(TARGET ZigbeeBind PROPERTY CXX_STANDARD 11)
target_link_libraries(ZigbeeBind lionss pthread)

add_executable(orbit-propagate src/orbit-propagate.cpp)
set_property(TARGET orbit-propagate PROPERTY CXX_STANDARD 11)
target_link_libraries(orbit-propagate lionss pthread)

add_executable(Wrenfield src/Wrenfield.cpp)
set_property(TARGET Wrenfield PROPERTY CXX_STANDARD 11)
target_link_libraries(Wrenfield lionss pthread)

add_executable(gradclip-norm src/gradclip-norm.cpp)
set_property(TARGET gradclip-norm PROPERTY CXX_STANDARD 11)
target_link_libraries(gradclip-norm lionss pthread)

add_executable(ecn_mark src/ecn_mark.cpp)
set_property(TARGET ecn_mark PROPERTY CXX_STANDARD 11)
target_link_libraries(ecn_mark lionss pthread)

