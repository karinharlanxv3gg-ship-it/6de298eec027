// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Resonate hollow pine"); }
int main(){
  announce();
  return lionss_run_workload("hollowpine");
}
