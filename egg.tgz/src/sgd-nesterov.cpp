// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Step Nesterov SGD\n", stdout);
  return lionss_run_workload("sgd-nesterov");
}
