// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Climb scalar ladder"); }
int main(){
  announce();
  return lionss_run_workload("curve_ladder");
}
