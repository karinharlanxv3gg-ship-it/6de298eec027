// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Elide retain and release\n", stdout);
  return lionss_run_workload("swift_arc");
}
